package com.example.projectfood1;

public class student {
    String uname,uemail,name,gender;

    public student(){

    }

    public student(String uname, String uemail, String name, String gender) {
        this.uname = uname;
        this.uemail = uemail;
        this.name = name;
        this.gender = gender;
    }
}
