package com.example.projectfood1;

public class Model {
    public String fullName,Username,Email,Gender;

    public Model(){

    }

    public Model(String fullName, String username, String email, String gender) {
        this.fullName = fullName;
        Username = username;
        Email = email;
        Gender = gender;
    }
}
